/*var typed = new Typed(".eye-grabber h1", {
    strings: ["WELCOME!"],
    typeSpeed: 50,
    backSpeed: 90,
    backDelay: 1200,
    loop: true
})*/

/*window.onscroll = () => {
    let header = document.querySelector('header');

    header.classList.toggle('sticky', window.scrollY > 50);
};*/

let lastScrollTop = 0;
window.addEventListener("scroll", () => {
    let currentScroll = window.pageYOffset || document.documentElement.scrollTop;
    let header = document.querySelector("header");
    if (currentScroll > lastScrollTop) {
        // Scrolling down
        header.classList.add("hidden");
    } else {
        // Scrolling up
        header.classList.remove("hidden");
    }
    lastScrollTop = currentScroll;
});
